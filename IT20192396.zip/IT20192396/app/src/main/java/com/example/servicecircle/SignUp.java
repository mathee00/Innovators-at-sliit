package com.example.servicecircle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity {

    TextInputLayout regFullname, regUsername, regEmail, regPassword;
    Button register, callLogin;

    FirebaseDatabase rootNode;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_sign_up);

        regFullname = findViewById(R.id.et_fullName);
        regUsername = findViewById(R.id.et_username);
        regEmail = findViewById(R.id.et_email);
        regPassword = findViewById(R.id.et_password);
        register = findViewById(R.id.btn_signUp);
        callLogin = findViewById(R.id.btn_aha);

        callLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUp.this, Login.class);
                startActivity(intent);
            }
        });
    }

    private Boolean validateFullname() {
        String val = regFullname.getEditText().getText().toString();

        if (val.isEmpty()) {
            regFullname.setError("Field cannot be empty");
            return false;
        } else {
            regFullname.setError(null);
            regFullname.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validateUsername() {
        String val = regUsername.getEditText().getText().toString();
        String noWhiteSpace = "\\A\\w{4,20}\\z";

        if (val.isEmpty()) {
            regUsername.setError("Field cannot be empty");
            return false;
        } else if (val.length() < 6 | val.length() > 12) {
            regUsername.setError("Username must 6 - 12 characters");
            return false;
        } else if (!val.matches(noWhiteSpace)) {
            regUsername.setError("No white spaces allowed");
            return false;
        } else {
            regUsername.setError(null);
            regUsername.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validateEmail() {
        String val = regEmail.getEditText().getText().toString();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        if (val.isEmpty()) {
            regEmail.setError("Field cannot be empty");
            return false;
        } else if (!val.matches(emailPattern)) {
            regEmail.setError("Invalid email address");
            return false;
        } else {
            regEmail.setError(null);
            regEmail.setErrorEnabled(false);
            return true;
        }
    }

    private Boolean validatePassword() {
        String val = regPassword.getEditText().getText().toString();
        String noWhiteSpace = "\\A\\w{4,20}\\z";

        if (val.isEmpty()) {
            regPassword.setError("Field cannot be empty");
            return false;
        } else if (val.length() < 8) {
            regPassword.setError("Username must 8 characters");
            return false;
        } else if (!val.matches(noWhiteSpace)) {
            regPassword.setError("No white spaces allowed");
            return false;
        } else {
            regPassword.setError(null);
            regPassword.setErrorEnabled(false);
            return true;
        }
    }

    public void registerUser(View view) {
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("users");

        if (!validateFullname() | !validateUsername() | !validateEmail() | !validatePassword()) {
            return;
        }

        String fullname = regFullname.getEditText().getText().toString();
        String username = regUsername.getEditText().getText().toString();
        String email = regEmail.getEditText().getText().toString();
        String password = regPassword.getEditText().getText().toString();


        UserHelperClass helperClass = new UserHelperClass(fullname, username, email, password);

        reference.child(username).setValue(helperClass);
        Intent intent = new Intent(getApplicationContext(), Login.class);
        startActivity(intent);
    }
}