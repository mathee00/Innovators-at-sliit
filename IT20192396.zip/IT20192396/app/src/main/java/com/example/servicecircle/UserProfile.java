package com.example.servicecircle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UserProfile extends AppCompatActivity {

    TextInputLayout upfullname, upusername, upemail;
    TextView usernameLabel;
    Button update;

    String _FULLNAME, _USERNAME, _EMAIL;

    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_user_profile2);

        reference = FirebaseDatabase.getInstance().getReference("users");

        upfullname = findViewById(R.id.et_fullName_profile);
        upusername = findViewById(R.id.et_username_profile);
        upemail = findViewById(R.id.et_email_profile);
        usernameLabel = findViewById(R.id.tv_fullname_profile);
        update = findViewById(R.id.btn_update);

        showAllUserData();
    }

    private void showAllUserData() {
        Intent intent = getIntent();
        String user_fullname = intent.getStringExtra("fullname");
        String user_username = intent.getStringExtra("username");
        String user_email = intent.getStringExtra("email");

        usernameLabel.setText(user_fullname);
        upfullname.getEditText().setText(user_fullname);
        upusername.getEditText().setText(user_username);
        upemail.getEditText().setText(user_email);

    }

    public void update(View view) {
        DatabaseReference updRef = FirebaseDatabase.getInstance().getReference("users");
        updRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    _FULLNAME = upfullname.getEditText().getText().toString();
                    _USERNAME = upusername.getEditText().getText().toString();
                    _EMAIL = upemail.getEditText().getText().toString();

                    reference.child(_USERNAME).child("fullname").setValue(upfullname.getEditText().getText().toString());
                    reference.child(_USERNAME).child("username").setValue(upusername.getEditText().getText().toString());
                    reference.child(_USERNAME).child("email").setValue(upemail.getEditText().getText().toString());
                    Toast.makeText(getApplicationContext(), "Data has been updated", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(getApplicationContext(), "No Source to Update", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    public void deleteUser(View view) {
        DatabaseReference delRef = FirebaseDatabase.getInstance().getReference().child("users");
        delRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    _USERNAME = upusername.getEditText().getText().toString();

                    reference = FirebaseDatabase.getInstance().getReference("users").child(_USERNAME);
                    reference.removeValue();
                    Toast.makeText(getApplicationContext(), "Data has been deleted", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), SignUp.class));
                } else
                    Toast.makeText(getApplicationContext(), "No Source to delete", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
}